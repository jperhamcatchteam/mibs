Readme.txt

-------------------------------------------------------------------
Release : 10.13 Halon
Last Updated Date : Oct 16th, 2023.

This file outlines changes since the last release of MIBs.

It is very strongly recommended that you load and compile ALL of
the MIBs provided.
-------------------------------------------------------------------

    ARUBAWIRED-NETWORKING-OID.mib
        -new objects
             arubaWiredSwitchJL724B
             arubaWiredSwitchJL725B
             arubaWiredSwitchJL726B
             arubaWiredSwitchJL727B
             arubaWiredSwitchJL728B
             arubaWiredSwitchS0M81A
             arubaWiredSwitchS0M82A
             arubaWiredSwitchS0M83A
             arubaWiredSwitchS0M84A
             arubaWiredSwitchS0M85A
             arubaWiredSwitchS0M86A
             arubaWiredSwitchS0M87A
             arubaWiredSwitchS0M88A
             arubaWiredSwitchS0M89A
             arubaWiredSwitchS0M90A
             arubaWiredSwitchS0G13A
             arubaWiredSwitchS0G14A
             arubaWiredSwitchS0G15A
             arubaWiredSwitchS0G16A
             arubaWiredSwitchS0G17A
             arubaWiredSwitchModuleJL724B
             arubaWiredSwitchModuleJL725B
             arubaWiredSwitchModuleJL726B
             arubaWiredSwitchModuleJL727B
             arubaWiredSwitchModuleJL728B
             arubaWiredSwitchModuleS0M81A
             arubaWiredSwitchModuleS0M82A
             arubaWiredSwitchModuleS0M83A
             arubaWiredSwitchModuleS0M84A
             arubaWiredSwitchModuleS0M85A
             arubaWiredSwitchModuleS0M86A
             arubaWiredSwitchModuleS0M87A
             arubaWiredSwitchModuleS0M88A
             arubaWiredSwitchModuleS0M89A
             arubaWiredSwitchModuleS0M90A
             arubaWiredSwitchModuleS0G13A
             arubaWiredSwitchModuleS0G14A
             arubaWiredSwitchModuleS0G15A
             arubaWiredSwitchModuleS0G16A
             arubaWiredSwitchModuleS0G17A

    ARUBAWIRED-SYSTEMINFO-MIB
        -new objects
            arubaWiredSystemInfoCpuAvgOneMin
            arubaWiredSystemInfoCpuAvgFiveMin

    ESO-CONSORTIUM-MIB.mib
        -new mib
            esoConsortiumMIBObjectIdentities
                usm3DESPrivProtocol
                usmAESCfb128PrivProtocol
                usmAESCfb192PrivProtocol
                usmAESCfb256PrivProtocol

    SNMP-USM-HMAC-SHA2-MIB.mib
        -new mib
            usmHMAC128SHA224AuthProtocol
            usmHMAC192SHA256AuthProtocol
            usmHMAC256SHA384AuthProtocol
            usmHMAC384SHA512AuthProtocol

    ARUBAWIRED-VSFv2-MIB.mib
        -new objects
            arubaWiredVsfv2MemberEntPhysicalIndex

    ARUBAWIRED-LED-LOCATOR-MIB
        -new mib
            arubaWiredLedLocatorTable
                arubaWiredLedLocatorGroupIndex
                arubaWiredLedLocatorName
                arubaWiredLedLocatorState

    ARUBAWIRED-SWITCH-IMAGE-MIB.mib
        -new mib
            arubaWiredDefaultBoot
            arubaWiredDefaultBootEnum
            arubaWiredBootProfileTimeout
            arubaWiredSwitchImageTable
                arubaWiredSwitchImageTypeEnum
                arubaWiredSwitchImageType
                arubaWiredSwitchImageVersion
                arubaWiredSwitchImageSize
                arubaWiredSwitchImageBuildDate
                arubaWiredSwitchImageSha

    POWER-STAT-MIB
        -new mib
            arubaWiredPowerStatTable
                arubaWiredPowerStatGroupIndex
                arubaWiredPowerStatTypeIndex
                arubaWiredPowerStatSlotIndex
                arubaWiredPowerStatName
                arubaWiredPowerStatType
                arubaWiredPowerStatPowerConsumed
                arubaWiredPowerStatPowerConsumedAverage
                arubaWiredPowerStatPowerConsumedAveragePeriod

    IPV6-MIB
        - obsolete mib

ARUBAWIRED-MACNOTIFY-MIB.mib
        - New trap objects supported in this release
             arubaWiredMacNotifyFromDest
             arubaWiredMacNotifyToDest
